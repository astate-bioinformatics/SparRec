Demo of LRMC-s algorithm:
	In the LRMC_s folder you will find a subfolder "demo".
	Running the MATLAB file "Demo_FPCA_vs_Mendel.m"
	in that folder will give the results for the 'chr22' 
	dataset. See the 'README.txt' in that folder for 
	additional information.

Demo of BCU and MBI-BL algorithms:
	Running the MATLAB file 'run_demo.m' in the MBI_BCU folder
	will execute a demonstration of these algorithms. See
	the 'README.txt' file in that folder for additional
	information.

