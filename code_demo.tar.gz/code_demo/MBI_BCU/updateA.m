% f = min || A- Y1*X*Y2' ||_F^2

function [A_NEW] = updateA(A,Y1,X,Y2,idx_known,int_flag)
A_NEW=Y1*X*Y2';
A_NEW(idx_known)=A(idx_known);

if int_flag
    A_NEW(A_NEW<0.5)=0;    
    A_NEW(A_NEW>=0.5)=1;
end 

end