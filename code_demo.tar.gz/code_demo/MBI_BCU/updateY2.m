% f = min || A- Y1*X*Y2' ||_F^2

function [Y2_NEW] = updateY2(A, Y1, X, K2,int_flag)
if int_flag
    TD = Y1*X;
    current = [];
    for j=1:K2
        difference = A - TD(:,ones(1,size(A,2))*j);
        current = [current;sum(difference.^2)]; %in order of columns
    end
    [~, idx] = min(current);%only the first min in idx
    K2_EYE = eye(K2);
    if K2==1
        Y2_NEW=1;
        return;
    end
    Y2_NEW = K2_EYE(idx,:);
else    
    purt = 1e-6; % by dsigma
    Y2_NEW = (A'*Y1*X) / (X'*(Y1'*Y1)*X+purt*eye(size(X,2))); 
end
end