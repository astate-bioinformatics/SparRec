%Calculate the RMSE
%Input	A: original matrix
%       As:matrix predicted
%       idx_pair: the pairs to compute

function RMSE = get_RMSE(A, As, idx_pair)
if nargin<3
    idx_pair = 1:1:(size(A,1)*size(A,2));
end
temp_A = A(idx_pair);
temp_As = As(idx_pair);
% RMSE = norm(temp_A - temp_As, 'fro')/sqrt(length(idx_pair));
RMSE = norm(temp_A - temp_As, 'fro')/max(1,norm(temp_As,'fro'));
end