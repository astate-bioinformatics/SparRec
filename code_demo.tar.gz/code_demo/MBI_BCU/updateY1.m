% f = min || A- Y1*X*Y2' ||_F^2

function [Y1_NEW] = updateY1(A, X, Y2, K1,int_flag)
if int_flag
    TD = X * Y2';
    current = [];
    for j=1:K1
        difference = A - TD(ones(1,size(A,1))*j,:);
        current = [current;sum(difference'.^2)]; %in order of rows
    end
    [~, idx] = min(current);%only the first min in idx
    K1_EYE = eye(K1);
    if K1==1
        Y1_NEW=1;
        return;
    end
    Y1_NEW = K1_EYE(idx,:);
    
else
    purt = 1e-6; % by dsigma
    Y1_NEW = (A*Y2*X') / (X*(Y2'*Y2)*X'+purt*eye(size(X,1)));
end
end