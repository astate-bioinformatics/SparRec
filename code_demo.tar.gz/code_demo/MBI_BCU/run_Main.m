clear all; clc

Reference = importdata('referenceHapMap3.csv');
Reference = Reference(1:300,:);
[mRef,nRef] = size(Reference);


O0 = importdata('study_completeHapMap3.csv');
O0 = O0(1:300,:);
[mStudy,nStudy] = size(O0);

M0=[Reference, O0];

M0(M0==-1) = Inf; 

% M0=importdata('dataset_00.csv');

% load('dataset_00_10missing');
% 
% M1=Data10missing;

% load('dataset_00_1missing');
% 
% M1=Data1missing;

O1=importdata('study_1_MissingHapMap3.csv');
O1 = O1(1:300,:);

idx_unknown = find(O0 ~= O1);

M1=[Reference,O1];

M1(M1==-1) = Inf; 

% 
% M0=importdata('chr22_3841_binary_format.csv');
% 
% % load('chr22_3841_10missing_binary');
% 
% % M1=Data10missing;
% 
% load('chr22_3841_1missing_binary');
% 
% M1=Data1missing;



% load('chr22');
% 
% M0=M;
% % 
% % load('chr22_10');
% % 
% % M1 = M;
% 
% load('Chr22_1missing');
% 
% M1=Data1missing;



% M0 =load('-ascii','1KG_chr22_selected_COMBINED_GROUNDTRUTH_ASCII');
% 
% M1 =load('-ascii','1KG_chr22_selected_COMBINED_masked_Inf_ASCII');



% load('KGchr22selectedstudyGROUNDTRUTH');
% 
% load('KGchr22selectedstudymasked');
% 
% M0 = KGchr22selectedstudyGROUNDTRUTH; 
% M1 = KGchr22selectedstudymasked; 

[m,n] = size(M1);

Vec=reshape(M0,m*n,1);


A = M0;
datasets = zeros(1,m,n); 
datasets(1,:,:) = M1; 
rate_missing = 1; 
K1_range=100;
% K2_range=[4,5,10];
K2_range=20;
% int_flag_range=[0 1];
int_flag_range=0;
verbose = 0 ;
seed=rng('default');
rs=[];
compares=[];



for idx_perinf= 1
%     A=reshape(datasets(1,:,:),size(datasets,2),size(datasets,3));
%     A_test=reshape(datasets(idx_perinf,:,:),size(datasets,2),size(datasets,3));
    A_test=M1;
    
    idx_known= find(A-A_test==0);
    idx_test= find(A_test==inf);
    A_test(idx_test)=0;
    A(isinf(A)>0)=0;
    rate_test = length(idx_test)/(size(A,1)*size(A,2));
    
    parfor idx_tot=0:(length(int_flag_range)*length(K1_range)*length(K2_range)-1)
        
        disp(sprintf('On going dataset:%d/%d, params testing: %d/%d',idx_perinf,length(rate_missing),(idx_tot+1),(length(int_flag_range)*length(K1_range)*length(K2_range))));
        temp_idx_tot=idx_tot;        temp_base=length(K1_range)*length(K2_range);
        idx_int_flag=floor(temp_idx_tot/temp_base)+1;
        temp_idx_tot=rem(temp_idx_tot,temp_base);        temp_base=length(K2_range);
        idx_K1=floor(temp_idx_tot/temp_base)+1;
        temp_idx_tot=rem(temp_idx_tot,temp_base);        temp_base=1;
        idx_K2=floor(temp_idx_tot/temp_base)+1;
        
        K1 = K1_range(idx_K1);
        K2 = K2_range(idx_K2);
        int_flag = int_flag_range(idx_int_flag);
        
%         time_start=tic;
%         [Xs,Y1s,Y2s,As,Scores_trace]=BCU_orig(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
%         time_elapse=toc(time_start)
%         temp_rs=[];
%         temp_rs.Xs=Xs;
%         temp_rs.Y1s=Y1s;
%         temp_rs.Y2s=Y2s;
%         temp_rs.K1=K1;
%         temp_rs.K2=K2;
%         temp_rs.int_flag=int_flag;
%         rs=[rs temp_rs];
%         As=Y1s*Xs*Y2s';
%         perct_recovery = get_perct(A, As, idx_test);
%         diff_A=norm(A-As,'fro');
%         diff_A_test=norm(A_test-As,'fro');
%         rmse_known = get_RMSE(A, As, idx_known);
%         rmse_test = get_RMSE(A, As, idx_test);
%         rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
%         idx_method=0;
%         temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
%         compares=[compares temp_compare'];
        
        fprintf('starting BCU_BL\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=BCU_BL(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        Track1 = Scores_trace;
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A(:,nRef+1:nRef+nStudy), As(:,nRef+1:nRef+nStudy), idx_unknown);
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=1;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
        
        
        fprintf('starting BCU_NX\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=BCU_NX(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        Track2 = Scores_trace;
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A(:,nRef+1:nRef+nStudy), As(:,nRef+1:nRef+nStudy), idx_unknown);
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=2;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
        
        fprintf('starting BCU\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=BCU(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A(:,nRef+1:nRef+nStudy), As(:,nRef+1:nRef+nStudy), idx_unknown);
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=3;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
        
        fprintf('starting MBI_BL\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=MBI_BL(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A(:,nRef+1:nRef+nStudy), As(:,nRef+1:nRef+nStudy), idx_unknown);
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=4;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
%         
%         time_start=tic;
%         [Xs,Y1s,Y2s,As,Scores_trace]=MBI_B(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
%         time_elapse=toc(time_start)
%         temp_rs=[];
%         temp_rs.Xs=Xs;
%         temp_rs.Y1s=Y1s;
%         temp_rs.Y2s=Y2s;
%         temp_rs.K1=K1;
%         temp_rs.K2=K2;
%         temp_rs.int_flag=int_flag;
%         rs=[rs temp_rs];
%         As=Y1s*Xs*Y2s';
%         perct_recovery = get_perct(A, As, idx_test);
%         diff_A=norm(A-As,'fro');
%         diff_A_test=norm(A_test-As,'fro');
%         rmse_known = get_RMSE(A, As, idx_known);
%         rmse_test = get_RMSE(A, As, idx_test);
%         rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
%         idx_method=5;
%         temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
%         compares=[compares temp_compare'];
%         
%         time_start=tic;
%         [Xs,Y1s,Y2s,As,Scores_trace]=MBI(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
%         time_elapse=toc(time_start)
%         temp_rs=[];
%         temp_rs.Xs=Xs;
%         temp_rs.Y1s=Y1s;
%         temp_rs.Y2s=Y2s;
%         temp_rs.K1=K1;
%         temp_rs.K2=K2;
%         temp_rs.int_flag=int_flag;
%         rs=[rs temp_rs];
%         As=Y1s*Xs*Y2s';
%         perct_recovery = get_perct(A, As, idx_test);
%         diff_A=norm(A-As,'fro');
%         diff_A_test=norm(A_test-As,'fro');
%         rmse_known = get_RMSE(A, As, idx_known);
%         rmse_test = get_RMSE(A, As, idx_test);
%         rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
%         idx_method=6;
%         temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
%         compares=[compares temp_compare'];
        
    end
end

compare1 = compares(:,1);
compare2 = compares(:,2);
compare3 = compares(:,3);
compare4 = compares(:,4);


% compare1 = [];
% compare2 = [];
% compare3 = [];
% compare4 = [];
% for i = 1 : 3
%     compare1 = [compare1 compares(:,1+(i-1)*4)];
%     compare2 = [compare2 compares(:,2+(i-1)*4)];
%     compare3 = [compare3 compares(:,3+(i-1)*4)];
%     compare4 = [compare4 compares(:,4+(i-1)*4)];
% end
[temp1, index1] = max(compare1(5,:));
[temp2, index2] = max(compare2(5,:));
[temp3, index3] = max(compare3(5,:));
[temp4, index4] = max(compare4(5,:));

error1 = 1- compare1(5,index1);
time1 = compare1(8,index1);
error2 = 1- compare2(5,index2);
time2 = compare2(8,index2);
error3 = 1- compare3(5,index3);
time3 = compare3(8,index3);
error4 = 1- compare4(5,index4);
time4 = compare4(8,index4);

fprintf('BUC-1 time: %4.3f, error rate: %1.6f\n',time1, error1);
fprintf('BUC-2 time: %4.3f, error rate: %1.6f \n',time2, error2);
fprintf('BUC-3 time: %4.3f, error rate: %1.6f \n',time3, error3);
fprintf('MBI-BL time: %4.3f, error rate: %1.6f \n',time4, error4);

% fprintf('MBI-BL time: %4.3f, error rate: %1.6f \n',time1, error1);

% [error1, time1]
% [error2, time2]
% [error3, time3]
% [error4, time4]

% save results_compare_methods_1KG_chr22_K2-20.mat compares
% save results_rs_methods_1KG_chr22_K2-20.mat rs

% save results_compare_methods_1KG_chr22_study_K2-20.mat compares
% save results_rs_methods_1KG_chr22_study_K2-20.mat rs

% save results_compare_methods_chr22_3841.mat compares
% save results_rs_methods_chr22_3841.mat rs

% save results_compare_methods_chr22_K2-20.mat compares
% save results_rs_methods_chr22_K2-20.mat rs


%num_methods=length(compares(3,:))/2;plot(1:num_methods,compares(3,1:num_methods),1:num_methods,compares(3,num_methods+1:num_methods*2));
