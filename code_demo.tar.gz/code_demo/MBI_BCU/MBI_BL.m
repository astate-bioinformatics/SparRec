% MBI Block Loop
% f = min || A- Y1*X*Y2' ||_F^2
% variables are Blocks Loops: X,Y1-X,Y2-X,A-X

function [X,Y1,Y2,A,scores_trace] = MBI_BL(A_in, K1, K2, idx_known,int_flag,itN,verbose,rng_seed)

if nargin<8
    % seed RNG
    rng('default');
else
    rng(rng_seed);
end

score_pre_round=Inf; % the score of last round
max_round_no_improved=3; %max round continue without improvement
thr_score=10e-7;
%int_flag = 0;

% seed RNG
rng('default')

%(1) Initialization
if verbose    fprintf('\nInitializing...\n');end
K1_EYE = eye(K1);
K2_EYE = eye(K2);

% K1_INDEX = kmeans(A,K1,'replicates',10,'emptyaction','singleton');%kmeans
% Y1 = K1_EYE(K1_INDEX,:);
% K2_INDEX = kmeans(A',K2,'replicates',10,'emptyaction','singleton');
% Y2 = K2_EYE(K2_INDEX,:);
% X = minimizeX(A, Y1, Y2);

% Y1=zeros(size(A,1),K1);%bad initial
% Y2=zeros(size(A,2),K2);
% for index_t=1:size(A,1)
%     Y1(index_t,mod(index_t,K1)+1)=1;
% end
% for index_t=1:size(A,2)
%     Y2(index_t,mod(index_t,K2)+1)=1;
% end
% X = minimizeX(A, Y1, Y2);

A = A_in;
[m,n] = size(A);
Y1 = eye(m, K1);
Y2 = eye(n, K2);
X = eye(K1,K2);


% Y1 = K1_EYE(randi(K1,size(A,1),1),:);%random initial
% Y2 = K2_EYE(randi(K2,size(A,2),1),:);
% X = randi(1,K1,K2);
%X = updateX(A, Y1, Y2);

% A = A_in;
% [Y1, X, Y2]=svd(A);

roundtime=1;
scores_trace=[];
while 1
    if verbose    fprintf('\nRound %d\n',roundtime);    end
    scores=[inf inf inf inf];
    
    %(1)updating X
    if verbose    fprintf('updating X\n');    end
    X_NEW = updateX(A, Y1, Y2);
    %scores(1)=obj_function(A_in-Y1*X_NEW*Y2');
    scores(1)=get_RMSE(Y1*X_NEW*Y2', A_in, idx_known);
        
    %(2)updating Y1
    if verbose         fprintf('updating Y1\n');    end
    score_cur= 1e8;
    score_pre= inf;
    Y1_NEW=Y1;
    while score_cur +0.01*thr_score< score_pre
        score_pre = score_cur;     
        if verbose         fprintf('-->minimizing X,%f\n',score_cur);    end
        X_NEW_Y1 = updateX(A, Y1_NEW, Y2);
        [Y1_NEW]=updateY1(A, X_NEW_Y1, Y2, K1,int_flag);
        score_cur=get_RMSE(Y1_NEW*X_NEW_Y1*Y2', A_in, idx_known);
    end    
    scores(2)=get_RMSE(Y1_NEW*X_NEW_Y1*Y2', A_in, idx_known);
    
    %(3)updating Y2
    if verbose        fprintf('updating Y2\n');    end 
    score_cur= 1e8;
    score_pre= inf;
    Y2_NEW=Y2;
    while score_cur +0.01*thr_score< score_pre
        score_pre = score_cur;
        if verbose         fprintf('-->minimizing X,%f\n',score_cur);    end
        X_NEW_Y2 = updateX(A, Y1, Y2_NEW);
        [Y2_NEW]=updateY2(A, Y1, X_NEW_Y2, K2,int_flag);
        score_cur=get_RMSE(Y1*X_NEW_Y2*Y2_NEW', A_in, idx_known);
    end
    scores(3)=get_RMSE(Y1*X_NEW_Y2*Y2_NEW', A_in, idx_known);
   
     %(4)updating A
    if verbose        fprintf('updating A\n');    end 
    score_cur= 1e8;
    score_pre= inf;
    A_NEW=A;
    while score_cur +0.01*thr_score< score_pre
        score_pre = score_cur;
        if verbose         fprintf('-->minimizing X,%f\n',score_cur);    end
        X_NEW_A=updateX(A_NEW, Y1, Y2);
        [A_NEW]=updateA(A_in,Y1,X_NEW_A,Y2,idx_known,int_flag);
        score_cur=get_RMSE(Y1*X_NEW_A*Y2', A_in, idx_known);
    end
    scores(4)=get_RMSE(Y1*X_NEW_A*Y2', A_in, idx_known);
    
    scores_trace=[scores_trace scores'];
            
    %(6)stopping criteria
    [score_cur_round,idx]=min(scores);
    if sum(isnan(scores))==4
        fprintf('---------------\nError updating in Nan!!\n');
        return;
    end
    if verbose        fprintf('current score is:%d\n',score_cur_round);    end
    if score_cur_round + thr_score>= score_pre_round % no improvement
        idx=find(scores == score_cur_round);
        idx=idx(randi(length(idx),1));
        max_round_no_improved = max_round_no_improved - 1;
        if max_round_no_improved <= 0
            break;
        end
    end
    
    %(7)update the variables
    switch idx
        case 1
            if verbose        fprintf('choose X\n');    end
            X=X_NEW;
        case 2
            if verbose        fprintf('choose Y1\n');    end
            Y1=Y1_NEW;
            X=X_NEW_Y1;
        case 3
            if verbose        fprintf('choose Y2\n');    end
            Y2=Y2_NEW;
            X=X_NEW_Y2;
        case 4
            if verbose        fprintf('choose A\n');    end
            A=A_NEW;
            X=X_NEW_A;
        otherwise
            fprintf('Buging max switch score!\n');
    end
    
    if score_cur_round < thr_score || roundtime>itN % good enough
        break;
    end
    score_pre_round = score_cur_round;
    roundtime=roundtime+1;
end

A=updateA(A,Y1,X,Y2,idx_known,int_flag);
end
