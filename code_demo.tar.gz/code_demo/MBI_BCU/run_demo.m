clear all; clc

M0=importdata('chr22_3841_binary_format.csv');


load('chr22_3841_1missing_binary');

M1=Data1missing;



% load('chr22');
% 
% M0=M;
% 
% load('Chr22_1missing');
% 
% M1=Data1missing;


[m,n] = size(M1);

Vec=reshape(M0,m*n,1);
idx_unknown = find(M0 ~= M1);

A = M0;
datasets = zeros(1,m,n); 
datasets(1,:,:) = M1; 
rate_missing = 1; 
K1_range=100;
% K2_range=[4,5,10];
K2_range=20;
% int_flag_range=[0 1];
int_flag_range=0;
verbose = 0 ;
seed=rng('default');
rs=[];
compares=[];




   A_test=M1;
    
    idx_known= find(A-A_test==0);
    idx_test= find(A_test==inf);
    A_test(idx_test)=0;
    A(isinf(A)>0)=0;
    rate_test = length(idx_test)/(size(A,1)*size(A,2));
    
    parfor idx_tot=0:(length(int_flag_range)*length(K1_range)*length(K2_range)-1)
        
        disp(sprintf('On going dataset:%d, params testing: %d/%d',length(rate_missing),(idx_tot+1),(length(int_flag_range)*length(K1_range)*length(K2_range))));
        temp_idx_tot=idx_tot;        temp_base=length(K1_range)*length(K2_range);
        idx_int_flag=floor(temp_idx_tot/temp_base)+1;
        temp_idx_tot=rem(temp_idx_tot,temp_base);        temp_base=length(K2_range);
        idx_K1=floor(temp_idx_tot/temp_base)+1;
        temp_idx_tot=rem(temp_idx_tot,temp_base);        temp_base=1;
        idx_K2=floor(temp_idx_tot/temp_base)+1;
        
        K1 = K1_range(idx_K1);
        K2 = K2_range(idx_K2);
        int_flag = int_flag_range(idx_int_flag);
        
        
        fprintf('starting BCU_BL\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=BCU_BL(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        Track1 = Scores_trace;
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A, As, idx_unknown);
        error_rate = 1 - perct_recovery; 
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=1;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
        fprintf('BUC-1 time: %4.3f, error rate: %1.6f\n',time_elapse, error_rate);
        
        fprintf('starting BCU_NX\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=BCU_NX(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        Track2 = Scores_trace;
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A, As, idx_unknown);
        error_rate = 1 - perct_recovery;  
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=2;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
        fprintf('BUC-2 time: %4.3f, error rate: %1.6f \n',time_elapse, error_rate);
        
        fprintf('starting BCU\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=BCU(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A, As, idx_unknown);
        error_rate = 1 - perct_recovery; 
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=3;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
        fprintf('BUC-3 time: %4.3f, error rate: %1.6f \n',time_elapse, error_rate);
        
        fprintf('starting MBI_BL\n')
        time_start=tic;
        [Xs,Y1s,Y2s,As,Scores_trace]=MBI_BL(A_test, K1, K2, idx_known,int_flag,500,verbose,seed);
        time_elapse=toc(time_start)
        temp_rs=[];
        temp_rs.Xs=Xs;
        temp_rs.Y1s=Y1s;
        temp_rs.Y2s=Y2s;
        temp_rs.K1=K1;
        temp_rs.K2=K2;
        temp_rs.int_flag=int_flag;
        rs=[rs temp_rs];
        As=Y1s*Xs*Y2s';
        perct_recovery = get_perct(A, As, idx_unknown);
        error_rate = 1 - perct_recovery; 
        diff_A=norm(A-As,'fro');
        diff_A_test=norm(A_test-As,'fro');
        rmse_known = get_RMSE(A, As, idx_known);
        rmse_test = get_RMSE(A, As, idx_test);
        rmse_total = get_RMSE(A, As, 1:1:size(A,1)*size(A,2));
        idx_method=4;
        temp_compare=[rate_test rmse_total rmse_test rmse_known perct_recovery diff_A diff_A_test time_elapse int_flag K1 K2 idx_method]
        compares=[compares temp_compare'];
        fprintf('MBI-BL time: %4.3f, error rate: %1.6f \n',time_elapse, error_rate);
        
    end


% compare1 = compares(:,1);
% compare2 = compares(:,2);
% compare3 = compares(:,3);
% compare4 = compares(:,4);
% 
% 
% 
% [temp1, index1] = max(compare1(5,:));
% [temp2, index2] = max(compare2(5,:));
% [temp3, index3] = max(compare3(5,:));
% [temp4, index4] = max(compare4(5,:));
% 
% error1 = 1- compare1(5,index1);
% time1 = compare1(8,index1);
% error2 = 1- compare2(5,index2);
% time2 = compare2(8,index2);
% error3 = 1- compare3(5,index3);
% time3 = compare3(8,index3);
% error4 = 1- compare4(5,index4);
% time4 = compare4(8,index4);






