Running the Demo on Linux/Windows (MATLAB GUI)
---------------------------------------------------------------------
    Open this folder in MATLAB GUI and simply type the following to 
    run the demo:

        run_demo


Running the Demo on Linux (console)
---------------------------------------------------------------------
    No configuration should be needed; you can just run the demo with 
    the following command:

        matlab -nodisplay -nosplash -r run_demo

