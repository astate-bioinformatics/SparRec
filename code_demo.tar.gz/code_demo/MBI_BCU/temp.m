% time_start=tic;
% [Xs,Y1s,Y2s,As,Scores_trace]=BCU_orig(A_test, K1_range(idx_K1), K2_range(idx_K2), idx_known,int_flag_range(idx_int_flag),500,verbose,seed);
% time_elapse2 = toc(time_start)

B_test=gpuArray(A_test);
time_start=tic;
[Xs,Y1s,Y2s,As,Scores_trace]=BCU_orig_gpu(B_test, K1_range(idx_K1), K2_range(idx_K2), idx_known,int_flag_range(idx_int_flag),500,verbose,seed);
time_elapse2 = toc(time_start)
