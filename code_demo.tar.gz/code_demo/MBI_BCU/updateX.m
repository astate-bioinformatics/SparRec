% f = min || A- Y1*X*Y2' ||_F^2
% X = argmin f = inv(Y1'*Y1)*Y1'*A*Y2*inv(Y2'*Y2);

function [X_NEW] = updateX(A, Y1, Y2)
% X_NEW = inv(Y1'*Y1) * (Y1'*A*Y2) * inv(Y2'*Y2);
Y1square = Y1'*Y1; 
Y2square = Y2'*Y2; 
purt = 1e-6; % by Prof Ma
X_NEW = (Y1square+purt*eye(size(Y1square))) \ ((Y1'*A*Y2) / (Y2square+purt*eye(size(Y2square))));
end