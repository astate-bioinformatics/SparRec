% Block Coordinate Update
% f = min || A- Y1*X*Y2' ||_F^2
% variables are Blocks Loops: A,X,Y1,X,Y2

function [X,Y1,Y2,A,scores_trace] = BCU_NX(A_in, K1, K2, idx_known,int_flag,itN,verbose,rng_seed)

if nargin<8
    % seed RNG
    rng('default');
else
    rng(rng_seed);
end

score_pre_round=Inf; % the score of last round
max_round_no_improved=3; %max round continue without improvement
thr_score=10e-7;
%int_flag = 0;

% seed RNG
rng('default')

%(1) Initialization
if verbose    fprintf('\nInitializing...\n');end
K1_EYE = eye(K1);
K2_EYE = eye(K2);

% K1_INDEX = kmeans(A,K1,'replicates',10,'emptyaction','singleton');%kmeans
% Y1 = K1_EYE(K1_INDEX,:);
% K2_INDEX = kmeans(A',K2,'replicates',10,'emptyaction','singleton');
% Y2 = K2_EYE(K2_INDEX,:);
% X = minimizeX(A, Y1, Y2);

% Y1=zeros(size(A,1),K1);%bad initial
% Y2=zeros(size(A,2),K2);
% for index_t=1:size(A,1)
%     Y1(index_t,mod(index_t,K1)+1)=1;
% end
% for index_t=1:size(A,2)
%     Y2(index_t,mod(index_t,K2)+1)=1;
% end
% X = minimizeX(A, Y1, Y2);

A = A_in;
[m,n] = size(A);
Y1 = eye(m, K1);
Y2 = eye(n, K2);
X = eye(K1,K2);


% Y1 = K1_EYE(randi(K1,size(A,1),1),:);%random initial
% Y2 = K2_EYE(randi(K2,size(A,2),1),:);
% X = randi(1,K1,K2);
%X = updateX(A, Y1, Y2);

% A = A_in;
% [Y1, X, Y2]=svd(A);

roundtime=1;
scores_trace=[];
while 1
    if verbose    fprintf('\nRound %d\n',roundtime);    end
    scores=[inf inf inf inf];
    
    %(4)updating A
    if verbose        fprintf('updating A\n');    end
    A=updateA(A_in,Y1,X,Y2,idx_known,int_flag);
    X = updateX(A, Y1, Y2);
    
    %(2)updating Y1
    if verbose         fprintf('updating Y1\n');    end
    Y1=updateY1(A, X, Y2, K1,int_flag);
    X = updateX(A, Y1, Y2);
    
    %(3)updating Y2
    if verbose         fprintf('updating Y2\n');    end
    Y2=updateY2(A, Y1, X, K2,int_flag);
    scores(1)=get_RMSE(Y1*X*Y2', A_in, idx_known);
    
    scores_trace=[scores_trace scores'];
    
    %(6)stopping criteria
    [score_cur_round,idx]=min(scores);
%     score_cur_round
    if sum(isnan(scores))==4
        fprintf('---------------\nError updating in Nan!!\n');
        return;
    end
    if verbose        fprintf('current score is:%d\n',score_cur_round);    end
    if score_cur_round + thr_score>= score_pre_round % no improvement
        idx=find(scores == score_cur_round);
        idx=idx(randi(length(idx),1));
        max_round_no_improved = max_round_no_improved - 1;
        if max_round_no_improved <= 0
            break;
        end
    end
    if score_cur_round < thr_score || roundtime>itN % good enough
        break;
    end
    score_pre_round = score_cur_round;
    roundtime=roundtime+1;
end

A=updateA(A,Y1,X,Y2,idx_known,int_flag);
end

