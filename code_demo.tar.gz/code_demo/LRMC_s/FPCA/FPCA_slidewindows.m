function out = FPCA_slidewindows(M1, M0)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M0 is the original matrix; M1 is the one with missing compoents and the
% missing components in M1 are set as Inf.
% sr is the sampling ratio.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%% Chr22 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load ../../../data/2016_05_25_bo_newtest/Chr22_1missing;
% load ../../../../original-data/chr22;
% M1 = Data1missing; M0 = M;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%% Chr22_3841 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load ../../../data/2016_05_25_bo_newtest/chr22_3841_1missing_binary;
% load ../../../../original-data/chr22_3841_binary_format;
% M1 = Data1missing; M0 = chr223841binaryformat;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%% dataset_00 (WTCCC) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load ../../../data/2016_05_25_bo_newtest/dataset_00_1missing;
% load ../../../../original-data/dataset_00;
% M1 = Data1missing; M0 = dataset00;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%% big dataset (Prepared by Jason) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load ('-ascii', '../../../../original-data/Mat_ASCII_CombinedPanels/1KG_chr22_selected_COMBINED_GROUNDTRUTH_ASCII.mat');
% load('-ascii', '../../../../original-data/Mat_ASCII_CombinedPanels/1KG_chr22_selected_COMBINED_masked_Inf_ASCII.mat');
% M1 = X1KG_chr22_selected_COMBINED_masked_Inf_ASCII;
% M0 = X1KG_chr22_selected_COMBINED_GROUNDTRUTH_ASCII;

% M1 = Data1missing; M0 = dataset00;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[m,n] = size(M1);

Vec=reshape(M0,m*n,1);

VecM1 = reshape(M1,m*n,1);
A1 = find(VecM1 ~= inf);
Mi1= find(VecM1 == inf);
b1 = VecM1 (A1);

MBlk = M1;

w = 100;
d = floor(m/w);

% Impute first window
MSubBlk = M1(1:w*3,:);
VecMSubBlk = reshape(MSubBlk,w*n*3,1);
ASubBlk = find(VecMSubBlk ~= inf);
bSubBlk = VecMSubBlk (ASubBlk);
%     sr = 0.99;
%     rp = round(w*n*sr*3);
%     r = 5; % r is the rank of the matrix M to be completed.
%     fr = r*(w*3+n-r)/rp;
%     maxr = 100;
%maxr = floor(((w*3+n)-sqrt((w*3+n)^2-4*rp))/2);
opts = get_opts_FPCA; %(VecMSubBlk,maxr,w*3,n,sr,fr);

Out1 = FPCA_MatComp(w*3,n,ASubBlk,bSubBlk,opts);

X = Out1.x(1:2*w,:);

for k = 2:d-2
    MSubBlk = M1(1+(k-1)*w:(k+2)*w,:);
    VecMSubBlk = reshape(MSubBlk,w*n*3,1);
    ASubBlk = find(VecMSubBlk ~= inf);
    bSubBlk = VecMSubBlk (ASubBlk);
    %     rp = round(w*n*sr*3);
    %     r = 5; % r is the rank of the matrix M to be completed.
    %     fr = r*(w*3+n-r)/rp; maxr = 100; %maxr = floor(((w*3+n)-sqrt((w*3+n)^2-4*rp))/2);
    opts = get_opts_FPCA; %(VecMSubBlk,maxr,w*3,n,sr,fr);
    
    %     fprintf('solving by FPCA Block: %d....\n',k);
    %     tic;
    Out1 = FPCA_MatComp(w*3,n,ASubBlk,bSubBlk,opts);
    %     solve_fpc = toc; Out1.solve_t = solve_fpc;
    %     fprintf('done!\n');
    X = [X;Out1.x(w+1:2*w,:)];
end

% Impute last window
MSubBlk = M1(1+k*w:m,:);
m2 = m - k*w;
VecMSubBlk = reshape(MSubBlk,m2*n,1);
ASubBlk = find(VecMSubBlk ~= inf);
bSubBlk = VecMSubBlk (ASubBlk);
% rp = round(m2*n*sr);
% r = 8; % r is the rank of the matrix M to be completed.
% fr = r*(m2+n-r)/rp; maxr = floor(((m2+n)-sqrt((m2+n)^2-4*rp))/2);
opts = get_opts_FPCA;%(VecMSubBlk,maxr,m2,n,sr,fr);

% fprintf('solving by FPCA Block: %d....\n',k);
% tic;
Out1 = FPCA_MatComp(m2,n,ASubBlk,bSubBlk,opts);
% solve_fpc = toc; Out1.solve_t = solve_fpc;
% fprintf('done!\n');
X = [X;Out1.x(w+1:m2,:)];



% Compute the error rate
c1=reshape(X,m*n,1);
c2=c1(A1);
c1(A1)=b1;
Infsl=find(c1<0);
c1(Infsl)=0;
Infsu=find(c1>1);
c1(Infsu)=1;
c1=round(c1);
reconverM1 = reshape(c1,m,n);

% fprintf('1Miss: Time = %3.2f, RecoverPercenty = %1.4f\n', solve_fpc, 1 - length(find(c1(Mi1)==Vec(Mi1)))/length(find(VecM1~=Vec)));
out.error = 1 - length(find(c1(Mi1)==Vec(Mi1)))/length(find(VecM1~=Vec)); 

% save('RecoverDatasetChr22_1','reconverM1');
