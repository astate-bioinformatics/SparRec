To run the demo:
	In the "demo" folder, run the file "Demo_FPCA_vs_Mendel.m" in MATLAB.
	This will give results for the "chr22" dataset.

