% compare FPCA + slide windows  and  Mendel 

%% Test 1: Chr22 

%%%%%%%%%%%%%%%%%%%% Chr22 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load ../data/Chr22_1missing;
load ../data/chr22;
M1 = Data1missing; M0 = M; sr = 0.99; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath ../FPCA; addpath ../Mendel/Chr22_Example; addpath ../Mendel/Functions;
tic; out_FPCA = FPCA_slidewindows(M1, M0); solve_fpca = toc; 
fprintf('Chr22: FPCA  : missing: %3.2f, Matrix size: %d, %d, Error: %10.6f, cpu: %10.6f\n', 1-sr, size(M1), out_FPCA.error, solve_fpca); 


tic; out_Mendel = Mendel_func(M1, M0); solve_Mendel = toc; 
fprintf('Chr22: Mendel: missing: %3.2f, Matrix size: %d, %d, Error: %10.6f, cpu: %10.6f\n', 1-sr, size(M1), out_Mendel.error, solve_Mendel); 
